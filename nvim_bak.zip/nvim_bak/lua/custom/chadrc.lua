---@type ChadrcConfig
local M = {}

M.ui = { theme = 'nightowl', transparency = true }
M.plugins = "custom.plugins"
M.mappings = require("custom.mappings")

vim.api.nvim_set_hl(0, "Visual", {
    fg = "Cyan",
    bg = "Gray",
    bold=true
})

return M
